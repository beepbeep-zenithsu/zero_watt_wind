import * as T from '../../vendor/three.module.js';
import { GLTFLoader } from '../../vendor/addons/loaders/GLTFLoader.js';

const loader = new GLTFLoader();
const library = new Map();
export const assetStatus = {loaded: new Set(), failed: new Map()};

export function loadAsset(name) {
  if (!library.has(name)) {
    // Relative to the document, including /zero_watt_wind/ on GitHub Pages.
    library.set(name, loader.loadAsync(`assets/zw-upgrade/${name}.glb`).then(gltf => {
      gltf.scene.traverse(o => {
        if (!o.isMesh) return;
        o.castShadow = o.receiveShadow = true;
        o.geometry.userData.sharedAsset = true;
        for (const m of Array.isArray(o.material) ? o.material : [o.material]) {
          m.userData.sharedAsset = true;
          m.envMapIntensity = .8;
        }
      });
      assetStatus.loaded.add(name);
      return gltf.scene;
    }).catch(error => {
      assetStatus.failed.set(name, error.message);
      console.warn(`ZeroWatt: original geometry retained for ${name}:`, error.message);
      return null;
    }));
  }
  return library.get(name);
}

export function disposeGeometry(root) {
  const geometries = new Set();
  root.traverse(o => {
    if (o.geometry && !o.geometry.userData.sharedAsset && !o.geometry.userData.sharedStatic) geometries.add(o.geometry);
  });
  geometries.forEach(g => g.dispose());
}

/** Contents change; the original pivot stays owned by FieldScene.render. */
export function upgradePart(group, name, {scale, rotation, replace = true} = {}) {
  group.userData.assetRequested = name;
  group.userData.assetReady = loadAsset(name).then(template => {
    if (!template || group.userData.retired) return false;
    if (replace) { disposeGeometry(group); group.clear(); }
    const model = template.clone(true);
    if (scale) model.scale.set(...scale);
    if (rotation) model.rotation.set(...rotation);
    model.name = `Blender ${name}`;
    group.add(model);
    group.userData.asset = name;
    return true;
  });
  return group;
}

export function addAsset(parent, name, position, scale = [1, 1, 1], rotation) {
  const group = new T.Group();
  group.position.set(...position); parent.add(group);
  return upgradePart(group, name, {scale, rotation});
}

/** Late loads must not resurrect an old layout. Cached GLBs stay shared. */
export function retireShell(root, sharedMaterials = []) {
  const keep = new Set(sharedMaterials), dispose = new Set();
  root.traverse(o => {
    o.userData.retired = true;
    if (o.isInstancedMesh) o.dispose();
    if (o.material) for (const m of Array.isArray(o.material) ? o.material : [o.material]) {
      if (!keep.has(m) && !m.userData.sharedAsset) dispose.add(m);
    }
  });
  disposeGeometry(root); dispose.forEach(m => m.dispose()); root.clear();
  root.userData.retired=false;
}
