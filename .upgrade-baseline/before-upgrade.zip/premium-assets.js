import * as T from './vendor/three.module.js';

let rotorPromise;
export function upgradeRotor(group) {
  // Keep the procedural rotor visible if an asset cannot be downloaded.
  rotorPromise ??= fetch('assets/premium/rotor.json')
    .then(response => {
      if (!response.ok) throw new Error(`Rotor asset: ${response.status}`);
      return response.json();
    })
    .then(parts => parts.map(part => {
      const geometry = new T.BufferGeometry();
      geometry.setAttribute('position', new T.Float32BufferAttribute(part.positions, 3));
      geometry.setAttribute('normal', new T.Float32BufferAttribute(part.normals, 3));
      geometry.computeBoundingSphere();
      const material = new T.MeshStandardMaterial({
        color: new T.Color().setRGB(...part.color),
        metalness: part.metalness, roughness: part.roughness, side: T.DoubleSide
      });
      return {name: part.name, geometry, material};
    }));
  rotorPromise.then(parts => {
    // Existing materials belong to the scene and must not be disposed here.
    for (const child of [...group.children]) {
      child.geometry?.dispose();
      group.remove(child);
    }
    for (const part of parts) {
      const mesh = new T.Mesh(part.geometry, part.material);
      mesh.name = part.name;
      mesh.castShadow = mesh.receiveShadow = true;
      group.add(mesh);
    }
    group.userData.asset = 'blender-premium-rotor';
  }).catch(error => console.warn('Using original rotor:', error.message));
}
