const {test}=require('node:test'),assert=require('node:assert/strict');
const {makeScene,ready,T,updateCity}=require('../tools/verify-graphics.cjs');
const M=require('../model.js');

test('Blender neighborhood and detailed site are installed in both applications',async()=>{
  for(const mode of ['air','water']){
    const s=makeScene(mode),p={...M.defaults,_mode:mode,units:1,boats:1,upb:1};
    s.setEnvironment({weather:'clear',environment:'park'},p);await ready(s);
    const neighborhood=s.scene.getObjectByName('Blender neighborhood');assert.ok(neighborhood);
    const apartments=neighborhood.children.filter(o=>o.userData.asset?.startsWith('site-apartment'));
    assert.equal(apartments.length,3);assert.ok(apartments.every(o=>o.children.every(m=>m.isInstancedMesh)));
    const buildings=neighborhood.children.filter(o=>o.userData.cityBuildings);
    assert.ok(buildings.reduce((count,b)=>count+b.children[0].count,0)>=100,'district has several blocks and a skyline');
    const quadrants=new Set(),matrix=new T.Matrix4(),point=new T.Vector3();
    for(const batch of buildings)for(let i=0;i<batch.children[0].count;i++){
      batch.children[0].getMatrixAt(i,matrix);point.setFromMatrixPosition(matrix);
      quadrants.add(`${Math.sign(point.x)},${Math.sign(point.z)}`);
      assert.ok(Math.abs(point.x)>s.city.hx||Math.abs(point.z)>s.city.hz,'buildings must stay outside the installation parcel');
    }
    for(const quadrant of ['-1,-1','-1,1','1,-1','1,1'])assert.ok(quadrants.has(quadrant));
    for(const name of ['Connected city streets','Continuous city sidewalks','Pedestrian zebra crossings','Civic plaza paving'])assert.ok(neighborhood.getObjectByName(name));
    assert.ok(s.shell.getObjectByName('Detailed landscaped site'));assert.ok(s.shell.getObjectByName('Jointed promenade pavers'));
    let meshes=0;neighborhood.traverse(o=>{if(o.isMesh)meshes++;});assert.ok(meshes<170,'dense district keeps a bounded draw-call budget');
    if(mode==='air'){
      assert.ok(s.shell.getObjectByName('Blender architectural details'));
      assert.ok(s.people[0].getObjectByName('Blender site-seated-person'));
      // Added trim and drain pipes must preserve the actual window apertures.
      s.scene.updateMatrixWorld(true);
      for(const pane of s.panes){
        const side=Math.sign(pane.x);
        const ray=new T.Raycaster(new T.Vector3(pane.x+side*.6,pane.y+.3,pane.zc+pane.width*.2),new T.Vector3(-side,0,0),0,1);
        const opaque=ray.intersectObjects(s.shell.children,true).filter(h=>!h.object.material.transparent);
        assert.equal(opaque.length,0,'window trim must stay clear of the inlet');
      }
    }else{
      assert.ok(s.shell.getObjectByName('Jointed pond coping stones'));
      assert.ok(s.boatGroups[0].getObjectByName('Blender site-deck-cleat'));
      assert.ok(s.boatGroups[0].getObjectByName('Blender site-lifebuoy'));
      assert.ok(s.fish[0].getObjectByName('Blender site-fish'));
    }
  }
});

test('Urban Canyon uses detailed Blender towers and keeps the inspection camera clear',async()=>{
  const s=makeScene('air'),p={...M.defaults,_mode:'air',units:1};
  s.setEnvironment({weather:'clear',environment:'canyon'},p);s.setView('field');await ready(s);
  s.scene.updateMatrixWorld(true);s.cameraPosition(true);
  assert.equal(s.canyon.visible,true);assert.equal(s.canyon.children.length,2);
  for(const tower of s.canyon.children){
    assert.equal(tower.userData.asset,'site-canyon-tower');
    assert.ok(new T.Box3().setFromObject(tower).getSize(new T.Vector3()).y>15);
  }
  const focus=new T.Vector3(0,3.7,0),direction=focus.clone().sub(s.camera.position);
  const ray=new T.Raycaster(s.camera.position,direction.clone().normalize(),0,direction.length());
  assert.equal(ray.intersectObject(s.canyon,true).length,0,'nearby towers must frame the installation, not hide it');
  s.setEnvironment({weather:'clear',environment:'roof'},p);assert.equal(s.canyon.visible,false);
  assert.ok(s.scene.getObjectByName('Blender neighborhood'),'ordinary weather still has the full city');
});

test('city traffic pauses with the simulation, responds to weather and has independent night lighting',async()=>{
  const s=makeScene('air'),p={...M.defaults,_mode:'air',units:1};
  s.setEnvironment({weather:'clear',environment:'roof'},p);await ready(s);s.reducedMotion=false;
  const sample=M.steady(p,p.wind,M.evaluateHardware(p));
  const before=s.city.cars.map(c=>c.phase);s.render(.1,sample,true);
  assert.ok(s.city.cars.some((c,i)=>c.phase!==before[i]));
  const paused=s.city.cars.map(c=>c.phase);s.render(.5,sample,false);assert.deepEqual(s.city.cars.map(c=>c.phase),paused);
  for(let i=0;i<360;i++){
    s.time+=.1;updateCity(s,.1);
    for(const car of s.city.cars)for(const other of s.city.cars){
      if(car===other||car.lane!==other.lane)continue;
      const gap=(other.phase-car.phase+1)%1*s.city.paths[car.lane].getLength();
      assert.ok(gap>5.49,'vehicles must queue behind a stopped vehicle without overlapping');
    }
  }
  s.setEnvironment({weather:'night',environment:'roof'},p);s.render(0,sample,false);
  assert.ok(s.city.lights.every(l=>l.intensity>0));
  assert.ok(s.city.batches.some(b=>b.userData.glowMaterials.some(m=>m.emissiveIntensity>1)));
  s.setEnvironment({weather:'rain',environment:'roof'},{...p,rain:.85});s.render(0,sample,false);
  assert.ok(s.city.lights.every(l=>l.intensity===0));assert.ok(s.city.roadMaterial.roughness<.4);
});

test('city rebuilds fit large installations and retire instances without disposing cached models',async()=>{
  for(const mode of ['air','water']){
    const s=makeScene(mode),p={...M.defaults,_mode:mode,units:1,boats:1,upb:1};
    s.setEnvironment({weather:'clear',environment:'park'},p);await ready(s);
    const old=s.city.root,mesh=s.city.traffic.children[0];let disposed=0,geometryDisposed=0;
    mesh.addEventListener('dispose',()=>disposed++);mesh.geometry.addEventListener('dispose',()=>geometryDisposed++);
    s.setEnvironment({weather:'clear',environment:'park'},{...p,units:mode==='air'?10:12,boats:6,upb:2,pond:500});await ready(s);
    assert.equal(old.userData.retired,true);assert.equal(disposed,1);assert.equal(geometryDisposed,0);
    const parcel=s.city.root.userData.parcel;
    assert.equal(parcel.width,mode==='air'?s.roomW:s.pondL);assert.equal(parcel.depth,mode==='air'?s.roomD:s.pondW);
    assert.ok(parcel.rx>parcel.width/2+10);assert.ok(parcel.rz>parcel.depth/2+10);
  }
});
